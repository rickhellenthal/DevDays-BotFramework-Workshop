﻿namespace DevDaysBot.Models
{
    public class UserProfile
    {
        public string Name { get; set; }
    }
}
