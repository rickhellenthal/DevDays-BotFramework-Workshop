// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DevDaysBot.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;

namespace DevDaysBot
{
    public class DevDaysBot : ActivityHandler
    {
        private BotState _conversationState;
        private BotState _userState;

        public DevDaysBot(ConversationState conversationState, UserState userState)
        {
            _conversationState = conversationState;
            _userState = userState;
        }

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            // Extract the conversationData from the state accessors
            var conversationStateAccessors = _conversationState.CreateProperty<ConversationData>(nameof(ConversationData));
            var conversationData = await conversationStateAccessors.GetAsync(turnContext, () => new ConversationData());

            // Extract the userProfile from the state accessors
            var userStateAccessors = _userState.CreateProperty<UserProfile>(nameof(UserProfile));
            var userProfile = await userStateAccessors.GetAsync(turnContext, () => new UserProfile());

            if (string.IsNullOrEmpty(userProfile.Name) && conversationData.PromptedForName)
            {
                userProfile.Name = turnContext.Activity.Text?.Trim();
                conversationData.PromptedForName = false;

                // Acknowledge that we got their name.
                await turnContext.SendActivityAsync($"Nice to meet you {userProfile.Name}!");

                // End the turn here.
                return;
            }

            switch (turnContext.Activity.Text.ToLower())
            {
                case "hello":
                    await turnContext.SendActivityAsync($"Hi {userProfile.Name}!");
                    break;
                case "bye":
                    await turnContext.SendActivityAsync($"Bye {userProfile.Name}!");
                    break;
                default:
                    await turnContext.SendActivityAsync($"I'm sorry {userProfile.Name}, I don't understand that.");
                    break;
            }
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            // Extract the conversationData from the state accessors
            var conversationStateAccessors = _conversationState.CreateProperty<ConversationData>(nameof(ConversationData));
            var conversationData = await conversationStateAccessors.GetAsync(turnContext, () => new ConversationData());

            // Extract the userProfile from the state accessors
            var userStateAccessors = _userState.CreateProperty<UserProfile>(nameof(UserProfile));
            var userProfile = await userStateAccessors.GetAsync(turnContext, () => new UserProfile());

            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    if (string.IsNullOrEmpty(userProfile.Name))
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Text($"Hi there, I am the DevDaysBot! What's your name?"), cancellationToken);
                        conversationData.PromptedForName = true;
                    }
                    else
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Text($"Hi {userProfile.Name}, welcome back!"), cancellationToken);
                    }
                }
            }
        }

        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default)
        {
            await base.OnTurnAsync(turnContext, cancellationToken);

            // Save any state changes that might have occured during the turn.
            await _conversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            await _userState.SaveChangesAsync(turnContext, false, cancellationToken);
        }
    }
}
