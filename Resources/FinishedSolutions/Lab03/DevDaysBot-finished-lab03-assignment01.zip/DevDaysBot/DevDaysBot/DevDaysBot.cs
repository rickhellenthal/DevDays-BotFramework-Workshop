// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using DevDaysBot.Models;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;

namespace DevDaysBot
{
    public class DevDaysBot : ActivityHandler
    {
        private BotServices _botServices;
        private BotState _conversationState;
        private BotState _userState;

        public DevDaysBot(ConversationState conversationState, UserState userState, BotServices botServices)
        {
            _botServices = botServices;
            _conversationState = conversationState;
            _userState = userState;
        }

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            // Extract the conversationData from the state accessors
            var conversationStateAccessors = _conversationState.CreateProperty<ConversationData>(nameof(ConversationData));
            var conversationData = await conversationStateAccessors.GetAsync(turnContext, () => new ConversationData());

            // Extract the userProfile from the state accessors
            var userStateAccessors = _userState.CreateProperty<UserProfile>(nameof(UserProfile));
            var userProfile = await userStateAccessors.GetAsync(turnContext, () => new UserProfile());


            // Handle the user's input if this is a response to the introduction question. This is the case when the user is not yet known to our bot.
            if (string.IsNullOrEmpty(userProfile.Name) && conversationData.PromptedForName)
            {
                userProfile.Name = turnContext.Activity.Text?.Trim();
                conversationData.PromptedForName = false;

                // Acknowledge that we got their name.
                await turnContext.SendActivityAsync($"Nice to meet you {userProfile.Name}!");

                // End the turn here.
                return;
            }


            // Retrieve the intent and recognizerResult from the TurnContext, this was added to the TurnContext in the IntentRecognizerMiddleware.
            string intent = turnContext.TurnState.Get<string>("Intent");
            RecognizerResult recognizerResult = turnContext.TurnState.Get<RecognizerResult>("recognizerResult");

            // Execute the desired logic based on the retrieved intent.
            switch (intent)
            {
                case "l_DevDaysLuisApplication":
                    await ProcessLuisResult(turnContext, recognizerResult.Properties["luisResult"] as LuisResult, cancellationToken, userProfile);
                    break;
                case "q_DevDaysQnA":
                    await ProcessQnA(turnContext, cancellationToken);
                    break;
                default:
                    await turnContext.SendActivityAsync($"I'm sorry {userProfile.Name}, I don't understand that.");
                    break;
            }
        }

        private async Task ProcessLuisResult(ITurnContext<IMessageActivity> turnContext, LuisResult luisResult, CancellationToken cancellationToken, UserProfile userProfile)
        {
            // Retrieve LUIS results.
            var result = luisResult.ConnectedServiceResult;
            var topIntent = result.TopScoringIntent.Intent;

            switch (topIntent)
            {
                case "GetLeaveBalance":
                    Random random = new Random();
                    // In a real application we would want to fetch the remaining leave hours from an actual source.
                    // For the purpose of this workshop a random number is generated.
                    await turnContext.SendActivityAsync($"You have {random.Next(1, 200)} hours left to use this year.");
                    break;
                case "CallInSickToday":
                    // For the purpose of this workshop we only send a confirmation message.
                    await turnContext.SendActivityAsync($"Alright, I've notified your manager, get better soon!");
                    break;
                default:
                    await turnContext.SendActivityAsync($"I'm sorry {userProfile.Name}, I don't understand that.");
                    break;
            }
        }

        private async Task ProcessQnA(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            var results = await _botServices.DevDaysQnA.GetAnswersAsync(turnContext);
            if (results.Any())
            {
                await turnContext.SendActivityAsync(MessageFactory.Text(results.First().Answer), cancellationToken);
            }
            else
            {
                await turnContext.SendActivityAsync(MessageFactory.Text("Sorry, could not find an answer in the Q and A system."), cancellationToken);
            }
        }


        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            // Extract the conversationData from the state accessors
            var conversationStateAccessors = _conversationState.CreateProperty<ConversationData>(nameof(ConversationData));
            var conversationData = await conversationStateAccessors.GetAsync(turnContext, () => new ConversationData());

            // Extract the userProfile from the state accessors
            var userStateAccessors = _userState.CreateProperty<UserProfile>(nameof(UserProfile));
            var userProfile = await userStateAccessors.GetAsync(turnContext, () => new UserProfile());

            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    if (string.IsNullOrEmpty(userProfile.Name))
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Text($"Hi there, I am the DevDaysBot! What's your name?"), cancellationToken);
                        conversationData.PromptedForName = true;
                    }
                    else
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Text($"Hi {userProfile.Name}, welcome back!"), cancellationToken);
                    }
                }
            }
        }

        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default)
        {
            await base.OnTurnAsync(turnContext, cancellationToken);

            // Save any state changes that might have occured during the turn.
            await _conversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            await _userState.SaveChangesAsync(turnContext, false, cancellationToken);
        }
    }
}
