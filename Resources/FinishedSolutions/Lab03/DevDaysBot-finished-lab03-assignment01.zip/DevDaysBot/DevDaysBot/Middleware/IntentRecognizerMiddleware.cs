﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.Luis;

namespace DevDaysBot.Middleware
{
    public class IntentRecognizerMiddleware : IMiddleware
    {
        private readonly LuisRecognizer dispatch;

        public IntentRecognizerMiddleware(BotServices botServices)
        {
            this.dispatch = botServices.Dispatch;
        }

        public async Task OnTurnAsync(ITurnContext turnContext, NextDelegate next, CancellationToken cancellationToken = default)
        {
            if (!string.IsNullOrEmpty(turnContext.Activity.Text))
            {
                var recognizerResult = await dispatch.RecognizeAsync(turnContext, cancellationToken);
                var (intent, score) = recognizerResult.GetTopScoringIntent();

                turnContext.TurnState.Add("Intent", intent);
                turnContext.TurnState.Add("recognizerResult", recognizerResult);
            }
            await next(cancellationToken);
        }
    }
}
