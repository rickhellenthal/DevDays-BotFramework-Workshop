﻿using Microsoft.Bot.Builder.AI.Luis;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Extensions.Configuration;

namespace DevDaysBot
{
    public class BotServices
    {
        public LuisRecognizer Dispatch { get; private set; }
        public QnAMaker DevDaysQnA { get; private set; }

        public BotServices(IConfiguration configuration)
        {
            Dispatch = new LuisRecognizer(new LuisApplication(
                configuration["LuisAppId"],
                configuration["LuisAPIKey"],
                configuration["LuisAPIHostName"]),
                new LuisPredictionOptions { IncludeAllIntents = true, IncludeInstanceData = true },
                includeApiResults: true);

            DevDaysQnA = new QnAMaker(new QnAMakerEndpoint
            {
                KnowledgeBaseId = configuration["QnAKnowledgebaseId"],
                EndpointKey = configuration["QnAEndpointKey"],
                Host = configuration["QnAEndpointHostName"]
            });
        }

    }
}
