﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.Luis;
using Microsoft.Extensions.Configuration;

namespace DevDaysBot.Middleware
{
    public class IntentRecognizerMiddleware : IMiddleware
    {
        private readonly LuisRecognizer luisRecognizer;

        public IntentRecognizerMiddleware(IConfiguration configuration)
        {
            var luisApplication = new LuisApplication(
                    configuration["LuisAppId"],
                    configuration["LuisAPIKey"],
                    configuration["LuisAPIHostName"]);

            luisRecognizer = new LuisRecognizer(luisApplication);
        }

        public async Task OnTurnAsync(ITurnContext turnContext, NextDelegate next, CancellationToken cancellationToken = default)
        {
            if (!string.IsNullOrEmpty(turnContext.Activity.Text))
            {
                var recognizerResult = await luisRecognizer.RecognizeAsync(turnContext, cancellationToken);
                var (intent, score) = recognizerResult.GetTopScoringIntent();

                turnContext.TurnState.Add("Intent", intent);
            }
            await next(cancellationToken);
        }
    }
}
