// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DevDaysBot.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.Luis;
using Microsoft.Bot.Schema;

namespace DevDaysBot
{
    public class DevDaysBot : ActivityHandler
    {
        private BotState _conversationState;
        private BotState _userState;

        public DevDaysBot(ConversationState conversationState, UserState userState)
        {
            _conversationState = conversationState;
            _userState = userState;
        }

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            // Extract the conversationData from the state accessors
            var conversationStateAccessors = _conversationState.CreateProperty<ConversationData>(nameof(ConversationData));
            var conversationData = await conversationStateAccessors.GetAsync(turnContext, () => new ConversationData());

            // Extract the userProfile from the state accessors
            var userStateAccessors = _userState.CreateProperty<UserProfile>(nameof(UserProfile));
            var userProfile = await userStateAccessors.GetAsync(turnContext, () => new UserProfile());


            // Handle the user's input if this is a response to the introduction question. This is the case when the user is not yet known to our bot.
            if (string.IsNullOrEmpty(userProfile.Name) && conversationData.PromptedForName)
            {
                userProfile.Name = turnContext.Activity.Text?.Trim();
                conversationData.PromptedForName = false;

                // Acknowledge that we got their name.
                await turnContext.SendActivityAsync($"Nice to meet you {userProfile.Name}!");

                // End the turn here.
                return;
            }


            // Retrieve the intent from the TurnContext, this was added to the TurnContext in the IntentRecognizerMiddleware.
            string intent = turnContext.TurnState.Get<string>("Intent");

            // Execute the desired logic based on the retrieved intent.
            switch (intent)
            {
                case "GetLeaveBalance":
                    Random random = new Random();
                    // In a real application we would want to fetch the remaining leave hours from an actual source.
                    // For the purpose of this workshop a random number is generated.
                    await turnContext.SendActivityAsync($"You have {random.Next(1, 200)} hours left to use this year.");
                    break;
                case "CallInSickToday":
                    // For the purpose of this workshop we only send a confirmation message.
                    await turnContext.SendActivityAsync($"Alright, I've notified your manager, get better soon!");
                    break;
                case "Greeting":
                    await turnContext.SendActivityAsync($"Hi {userProfile.Name}!");
                    break;
                case "Bye":
                    await turnContext.SendActivityAsync($"Bye {userProfile.Name}!");
                    break;
                case "Help":
                    await turnContext.SendActivityAsync($"I am the DevDaysBot");
                    break;
                default:
                    await turnContext.SendActivityAsync($"I'm sorry {userProfile.Name}, I don't understand that.");
                    break;
            }
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            // Extract the conversationData from the state accessors
            var conversationStateAccessors = _conversationState.CreateProperty<ConversationData>(nameof(ConversationData));
            var conversationData = await conversationStateAccessors.GetAsync(turnContext, () => new ConversationData());

            // Extract the userProfile from the state accessors
            var userStateAccessors = _userState.CreateProperty<UserProfile>(nameof(UserProfile));
            var userProfile = await userStateAccessors.GetAsync(turnContext, () => new UserProfile());

            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    if (string.IsNullOrEmpty(userProfile.Name))
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Text($"Hi there, I am the DevDaysBot! What's your name?"), cancellationToken);
                        conversationData.PromptedForName = true;
                    }
                    else
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Text($"Hi {userProfile.Name}, welcome back!"), cancellationToken);
                    }
                }
            }
        }

        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default)
        {
            await base.OnTurnAsync(turnContext, cancellationToken);

            // Save any state changes that might have occured during the turn.
            await _conversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            await _userState.SaveChangesAsync(turnContext, false, cancellationToken);
        }
    }
}
